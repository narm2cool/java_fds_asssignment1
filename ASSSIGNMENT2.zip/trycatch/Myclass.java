package trycatch;


public class Myclass 
{
    public static void main(String args[]) 
    {
        
        try 
        {
           System.out.println(10/0);
        }
        catch (ArithmeticException e) 
        {
            System.out.println("divisor zero not allowed"+e); 
        }
        finally 
        {
            System.out.println("try another number instead of 0");
        }
    }
}
