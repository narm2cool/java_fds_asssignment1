package throethroesfinally;


public class Main 
{ 
    public static void main(String args[]) 
    { 
        try
        { 
            throw new customecxeption("custom exception is thrown"); 
        } 
        catch (customecxeption ex) 
        { 
            System.out.println("Caught"); 
            System.out.println(ex.getMessage()); 
        } 
    } 
}

