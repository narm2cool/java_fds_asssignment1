package throethroesfinally;

public class customecxeption extends Exception{
	public customecxeption(String s){
		super(s);
	}

}
