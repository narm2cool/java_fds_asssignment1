package question9;

 
interface Second 
{  
    default void show() 
    { 
        System.out.println("Default Second"); 
    } 
}  

