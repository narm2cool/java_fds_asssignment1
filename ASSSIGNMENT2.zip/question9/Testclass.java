package question9;


public class Testclass implements First, Second 
{  
    public void show() 
    {  
        First.super.show(); 
        Second.super.show(); 
    } 
    public static void main(String args[]) 
    { 
        Testclass ob = new Testclass(); 
        ob.show(); 
    } 
}
