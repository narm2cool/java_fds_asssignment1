package questioon9;


	class Main {
	  public static void main(String[] args) {

	    // create an object of the subclass
	    puppy labrador = new puppy();

	    // call the eat() method
	    labrador.eat();
	    labrador.bark();
	  }
	}
