package questioon9;

class Animal {

	  // method in the superclass
	  public void eat() {
	    System.out.println("I can eat");
	  }
	}
