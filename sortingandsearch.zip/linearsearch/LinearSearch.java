package linearsearch;

import java.util.Scanner;

public class LinearSearch {
    public void search(int a[],int n,int key)
    {
    	int t =0;
    	for(int i=0;i<n;i++)
    	{
    		if(a[i]==key)
    		{
    			System.out.println("The key is found at index "+i);
    			t++;
    		}
    	}
    		if(t==0)
    		{
    			System.out.println("The key is not found ");
    		}
    	}
    


public static void main(String args[])
{
	int a[]= {1,3,2,4,5,4};
	int n=a.length;
	int key;
	System.out.println("Enter the value to search in the array of numbers");
	Scanner sc =new Scanner(System.in);
	key=sc.nextInt();
	LinearSearch w=new LinearSearch();
	w.search(a,n,key);
}
}
