package arrayrotation;

public class Main {
	public static void main(String args[])
	{
		int arr[]= {1,2,3,4,5,6,7};
		int m=arr.length;
		ArrayRotation r= new ArrayRotation();
		r.Rotation(arr, m,2);
		for(int i=0;i<m;i++)
		{
			System.out.println(arr[i]);
		}
		
		
	}
}
/*public class Main
{
	public static void main(String[] args) {
		ArrayRotation r = new ArrayRotation();
        		int arr[] = { 1, 2, 3, 4, 5, 6, 7 }; 
        		r.rotate(arr, 5); 
        		for(int i=0;i<arr.length;i++){
            			System.out.print(arr[i]+" ");
        		}
	}
}
*/
