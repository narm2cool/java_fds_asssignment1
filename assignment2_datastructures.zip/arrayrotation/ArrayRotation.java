package arrayrotation;

public class ArrayRotation {
	 public void Rotation(int[] arr, int m,int k) {
		if(k>m)
		{
			k=k%m;
		}
		int i;
		for(i=0;i<k;i++)
		{int temp=arr[0];
			for(int j=0;j<m-1;j++)
			{
				arr[j]=arr[j+1];
			}
			arr[m-1]=temp;
	
		}
	}
}
/*
class ArrayRotation { 
public void rotate(int[] nums, int k) {
    		if(k > nums.length) 
       			k=k%nums.length;
 		int[] result = new int[nums.length];
 		for(int i=0; i < k; i++){
        			result[i] = nums[nums.length-k+i];
 		}
 		int j=0;
    		for(int i=k; i<nums.length; i++){
        			result[i] = nums[j];
j++;
    		}
 		System.arraycopy( result, 0, nums, 0, nums.length );
}
} */
