package protected1;

public class A {
	protected void msg(){System.out.println("Hello");} 
}
