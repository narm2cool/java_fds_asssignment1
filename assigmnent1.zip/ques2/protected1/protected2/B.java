package protected2;
import protected1.*;

public class B {
B arg= new B();
arg.msg();
}
