package private1;

public class A {
private void msg()
{System.out.println("Hello java");} 
}
