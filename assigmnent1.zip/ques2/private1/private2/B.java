package private2;
import private1.*;
public class B {
	 A obj=new A();
	  obj.msg();
}
