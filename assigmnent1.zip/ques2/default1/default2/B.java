package default2;  
import default1.*;  
class B{  
  public static void main(String args[]){  
   A obj = new A();  
   obj.msg();  
  }  
}