package default1;

 class A {
	 void msg(){System.out.println("Hello");} 

}
