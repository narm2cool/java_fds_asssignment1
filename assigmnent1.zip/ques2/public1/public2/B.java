package public2;
import public1.*;

public class B {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     A v = new A();
     v.msg();
	}

}
