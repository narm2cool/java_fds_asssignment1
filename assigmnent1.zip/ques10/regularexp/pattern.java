package regularexp;
import java.util.regex.Pattern;
public class pattern {

	
	 
	    public static void main(String args[])
	    {
	 
	      
	        System.out.println(Pattern.matches( "Hell*", "Hello"));
	 

	        System.out.println( Pattern.matches("He*lo", "Hello"));
	    }
	}

