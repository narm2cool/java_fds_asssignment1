package collection;

import java.util.*;  
public class linkedlist{  
public static void main(String args[]){  
LinkedList<String> ll=new LinkedList<String>();  
ll.add("kavitha");  
ll.add("Vinith");  
ll.add("imran");  
ll.add("Ajay");  
Iterator<String> itr=ll.iterator();  
while(itr.hasNext()){  
System.out.println(itr.next());  
}  
}  
}  
