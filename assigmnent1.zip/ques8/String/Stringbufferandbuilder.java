package String;

class	Stringbufferandbuilder
{
  public static void main(String args[]) 
    {
       String str = "HI";
       String str2 = str;
       StringBuffer strbuff = new StringBuffer("Hello");
       StringBuffer strbuff2 = strbuff;
       StringBuilder strbuild = new StringBuilder("Welcome");
       StringBuilder strbuild2 = strbuild;

       str = str + " user";
       strbuff = strbuff.append(" world");
       strbuild = strbuild.append(" you");
       
       System.out.println("str = "+str);
       System.out.println("str2 = "+str2);
       System.out.println("strbuff = "+strbuff);
       System.out.println("strbuff2 = "+strbuff2);
       System.out.println("strbuild = "+strbuild);
       System.out.println("strbuild2 = "+strbuild2);
    }
}		