package methodimplementation;
import java.util.Scanner;

public class method1 {
	public static void addition() {
		int a,b,c;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter two numbers for addition");
		a=sc.nextInt();
		b=sc.nextInt();
		c=a+b;
		System.out.println("addtition of a and b is "+c);
	}
	public static void main(String args[])
	{
		addition();
	}
	

}
