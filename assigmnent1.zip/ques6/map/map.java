package map;

	import java.util.*;  
	class map{  
	 public static void main(String args[]){  
	  Map<Integer,String> map=new HashMap<Integer,String>();  
	  map.put(1,"brinjal");  
	  map.put(2,"tomatoes");  
	  map.put(3,"potato");  
	  System.out.println("list of groceries");
	  //Elements can traverse in any order  
	  for(Map.Entry m:map.entrySet()){  
	   System.out.println(m.getKey()+" "+m.getValue());  
	  }  
	 }  
	}

