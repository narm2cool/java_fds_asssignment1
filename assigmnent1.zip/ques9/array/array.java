package array;

public class array {
	
	    public static void main(String[] args)
	    {
	        
	        
	       
	       int[] arr = {1,2,3,4,5};
	  
	        // initialize the second elements of the array
	      
	        // accessing the elements of the specified array
	        for (int i=0;i<arr.length;i++)
	            System.out.println(arr[i]);
	    }
	}

