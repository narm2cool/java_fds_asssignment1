package typecasting;

public class typecasting1 {
	public static void main(String[] args)
	{   //explicittypecasting
		int x=3;
		float y =x;
		System.out.println("explicit type casiting(int=--->float" +y);
		//implicit type casting
		double mydouble = 55.44;
		int a= (int) mydouble;
		System.out.println("implicit type casting (double-->int) "+a);
		
		
	}

}
