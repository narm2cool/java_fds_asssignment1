package defaul.consturctor;

public class Zero {
	

		int a;
		float b;
	public static void main (String[] args)
	{
		Zero obj=new Zero();
		System.out.println("default integer vaalue is "+obj.a);
		System.out.println("default float vaalue is "+obj.b);
		
	}
	
	
	

}
