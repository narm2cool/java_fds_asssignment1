package noarg.constructor;

public class noarg {
		  private int a;

		  // constructor
		  noarg() {
		    System.out.println("Constructor Called:");
		    a =5;
		  }

		  public static void main(String[] args) {

		    // constructor is invoked while
		    // creating an object of the Main class
		    noarg obj = new noarg();
		    System.out.println("The value of a is " + obj.a);
		  }
		}


