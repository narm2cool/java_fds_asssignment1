package parameterised.constructor;

public class parameterised {
	parameterised(int a)
	{
		int add;
		add=5+a;
		System.out.println("sum is "+add);
	}
	
public static void main(String[] args)
{
 parameterised sum = new parameterised(2);
}
	

}
