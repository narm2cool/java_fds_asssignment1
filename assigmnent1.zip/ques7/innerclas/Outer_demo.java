package innerclas;

class Outer_Demo {
	   int num;
	   
	   // inner class
	   class Inner_Demo {
		   int a=1;
	   }
	    /*  public void print() {
	         System.out.println("This is an inner class");
	      }
	   }
	   
	   // Accessing he inner class from the method within
	   void display_Inner() {
	      Inner_Demo inner = new Inner_Demo();
	      inner.print();
	   } */
	}
	   
	