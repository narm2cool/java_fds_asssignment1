package innerclas;

public class My_class {

	   public static void main(String args[]) {
	      // Instantiating the outer class 
	      Outer_Demo outer = new Outer_Demo();
	      Outer_Demo.Inner_Demo inn= outer. new Inner_Demo();
	     System.out.println( inn.a);
	      
	    
	   }
	}